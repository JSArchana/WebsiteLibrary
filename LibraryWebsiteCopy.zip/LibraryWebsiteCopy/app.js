const express = require('express');
const app = new express();
//const bodyparser = require('body-parser');
const nav =[
    {
        link:'/books',name:'Books'
    }, 
    {
        link:'/authors',name:'Authors'    
    }, 
    {
        link:'/admin', name: 'Add Book'
    }

] ;
const navSign =[
    {
         Link:'/login',Name:'Log In'
    },     
    {
         Link:'/signup',Name:'Sign Up'
    }
];   

const booksRouter = require('./src/routes/booksRoute')(nav,navSign);
const authorsRouter = require('./src/routes/authorsRoute')(nav,navSign);
const adminRouter = require('./src/routes/adminRoute')(nav,navSign);


app.use(express.urlencoded({extended:true}));
app.use(express.static('./public'));
app.set('view engine','ejs');
app.set('views', './src/views');
app.use('/books',booksRouter);
app.use('/authors',authorsRouter);
app.use('/admin',adminRouter);
//app.use(express.bodyParser());


app.get('/',function(req,res){
    res.render("index",{
        nav,
        navSign
     });
});

app.listen(5000);
console.log('port 5000');