const express = require('express');
const booksRouter = express.Router();
const Bookdata = require('../model/Bookdata');

function router(nav,navSign){
    // var books =[
    //     {
    //         title:'Diary of a Wimpy Kid: The Last Straw',
    //         author:'Greg Heffley',
    //         genre:'Diary Fiction',
    //         image:"diaryofawimpykid.jpg"
    //     },
    //     {
    //         title:"Harry Potter and the Philosopher's Stone",
    //         author:'J K Rowling',
    //         genre:'Fantasy',
    //         image:"harry-potter-and-the-sorcerer-s-stone-3.jpg"
    //     },
    //     {
    //         title:"Happy Birthday World!",
    //         author:'Ruskin Bond',
    //         genre:'Juvenile Fiction',
    //         image:"happybirthdayworld.jpg"
    //     }
    // ];
    booksRouter.get('/',function(req,res){
        
        // res.render("books",{
        //     nav,
        //     navSign,
        //     books
        //  });
        Bookdata.find()
        .then(function(books){
            res.render("books",{nav,navSign,books});
        })
    });
    return booksRouter;
}

module.exports = router;