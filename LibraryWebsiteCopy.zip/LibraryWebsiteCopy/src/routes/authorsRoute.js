const express = require('express');
const authorsRouter = express.Router();

function router(nav,navSign){
    var authors=[
        {
            author:'Jeff Kinney',
            img:'jeff-kinney.jpg'
        },
        {
            author:'Ruskin Bond',
            img:'Ruskin-Bond.jpg'
        },
        {
            author:'J. K. Rowling',
            img:'Rowling.jpg'
        }
    ];
    authorsRouter.get('/',function(req,res){
        res.render("authors",{
            nav,
            navSign,
            authors
         });
    });
    return authorsRouter;
}
module.exports = router;